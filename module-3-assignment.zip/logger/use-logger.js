//use logger and emit sample events for
