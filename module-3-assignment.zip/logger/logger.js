/*
  Below code has functions which are used to log different types of messages into console.
  Convert the following code into a module and enable event based login
*/
let chalk = require("chalk");
let util = require("util");
let EventEmitter = require("events").EventEmitter;

function info(source, message) {
  let date = new Date();
  console.log(
    chalk.green(
      `${date.toDateString()} ${date.toTimeString()} INFO ${JSON.stringify(
        message
      )}`
    )
  );
}

function debug(source, message) {
  let date = new Date();
  console.log(
    chalk.blue(
      `${date.toDateString()} ${date.toTimeString()} DEBUG ${JSON.stringify(
        message
      )}`
    )
  );
}

function error(source, message) {
  let date = new Date();
  console.log(
    chalk.red(
      `${date.toDateString()} ${date.toTimeString()} ERROR ${JSON.stringify(
        message
      )}`
    )
  );
}
