/*
  Write a nodejs program thats reads data from keyboard and display processed output to console using streams 
  
  Program should collect responses for the following questions and should display the all response at the end of 3 questions
  ["What is your name? ", "How old are you? ", "Where are you from? "];

  Hint: 
  use process.stdin as input stream and process.stdout as output stream

 let inputStream = process.stdin;
 let outputStream = process.stdout;

 */
