//print console.logs in different colors

// use the date-util module in this module

// print current date time
// print date time for 25th Jan 2017 6 PM

// print the days diff between today and Jun 8th 2001

// print the month name for 25th November 2011