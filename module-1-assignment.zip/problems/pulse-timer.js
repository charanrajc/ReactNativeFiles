/*
create a code that display the current date time for random number of times.
Random number must be between 1 and 10

test case:

1. 

showTime();

2018-02-05 15:49:01
2018-02-05 15:49:02
2018-02-05 15:49:03

2.
showTime();

2018-02-05 15:49:01
2018-02-05 15:49:02

*/
