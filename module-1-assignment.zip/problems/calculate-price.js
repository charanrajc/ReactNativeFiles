function calculatePrice(price, tax, discount){
	//total = price + tax - discount
}

let price, tax, discount;

calculatePrice(price,tax,discount)